# Cardinal Finds — CIS 2368 Midterm Update

This version begins the playful/colorful redesign on `item.html` while preserving the original five-page site and folder structure.

## Open the website
1. Extract this ZIP.
2. Open the `sandbox` folder.
3. Double-click `item.html` to test the item-detail page, or open `index.html` for the homepage.
4. Keep the `css`, `js`, and `images` folders beside the HTML files. Do not move individual files out of their folders.

## What changed on item.html
- The page branding now says **Cardinal Finds**.
- The featured item is a fictional “Mystery Fun Pack: Desk Toys & Tiny Treasures.”
- Three local SVG illustrations are used in the clickable thumbnail gallery.
- A scoped CSS theme adds pastel colors, gradients, rounded cards, and playful buttons.
- The existing shared `main.css`, personal `maria.css`, and scripts are still linked externally.
- `maria.js` now provides matching product details so JavaScript does not replace the new item with the old textbook content.
- Existing comments and semantic HTML elements are preserved; added comments explain the modification.

## Midterm concepts to explain
- **HTML:** page structure, headings, navigation, image elements, buttons, and product details.
- **CSS:** external stylesheets, class selectors, hover states, gradients, and responsive media queries.
- **JavaScript:** DOM selection, `DOMContentLoaded`, event listeners, image swapping, offer calculation, and message feedback.
- **File paths:** `css/maria.css`, `js/maria.js`, and `images/fun-pack.svg` are relative to the `sandbox` folder.

Note: This is a front-end class demo. Offer/message buttons provide demo interactions; they do not contact a real seller or process real payments.
